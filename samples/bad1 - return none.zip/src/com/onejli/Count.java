package com.onejli;

import java.lang.String;
import java.lang.System;

public class Count {
	public String doStuff(String[] args) {
		return "";
	}

	public static void main(String[] args) {
		Count c = new Count();
		System.out.println(c.doStuff(args));
	}
}
